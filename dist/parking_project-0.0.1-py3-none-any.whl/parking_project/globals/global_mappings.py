"""
This file contains mappings for Strings Used in the Program.
"""

CREATE_PARKING_LOT = 'Create_parking_lot'
PARK = 'Park'
LEAVE = 'Leave'
FETCH_VEHICLE_REG_NO_FOR_AGE = 'Vehicle_registration_number_for_driver_of_age'
FETCH_SLOTS_USING_DRIVER_AGE = 'Slot_numbers_for_driver_of_age'
FETCH_SLOTS_USING_REG_NO = 'Slot_number_for_car_with_number'
EXIT = "exit"
