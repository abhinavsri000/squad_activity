
import unittest

class helper_tests(unittest.TestCase):

    def test_check_for_no_input_file(self):
        # output = parse_file('./test_resources/inputs/input0.txt')
        # self.assertEqual(output , line = "")

if __name__ == "__main__":
    unittest.main()
