class Driver:
    def __init__(self,age):
        self.age = int(age)
